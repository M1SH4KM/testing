## Description

<!-- What does your pull request change? Why should it be merged? Does it fix an issue? -->

## Checklist

<!-- Put an x inside the [ ] to check an item, like so: [x] -->

-   [ ] I have personally loaded this code into an updated qbcore project and checked all of its functionality.
-   [ ] My code fits the style guidelines.
-   [ ] My PR fits the contribution guidelines.